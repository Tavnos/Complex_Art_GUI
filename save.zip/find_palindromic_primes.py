hot_pot,end_pot,pal_pot = [],[],[]

for i in pot[::-1]:
    hot_pot+=[str(i)]
for x in range(100):
    for i in hot_pot:
        if (i.startswith('2')== 1 
            or i.startswith('4')==1 
            or i.startswith('5')==1
            or i.startswith('6')==1 
            or i.startswith('8')==1):
            hot_pot.remove(i)
for i in range(len(hot_pot)):
    chunk_ls = [''.join([*(hot_pot[i][0:int((len(hot_pot[i]))/2)])]), 
                ''.join([*(hot_pot[i][0:int((len(hot_pot[i]))/2)])][::-1])]
    if (hot_pot[i].startswith(chunk_ls[0]) == 1)  and (hot_pot[i].endswith(chunk_ls[1])==1):
        pal_pot += [hot_pot[i]]
